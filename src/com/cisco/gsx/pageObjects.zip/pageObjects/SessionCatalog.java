package com.cisco.gsx.pageObjects;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Properties;

import org.openqa.selenium.WebElement;

import com.cisco.gsx.util.PropertiesFileReader;
import com.cisco.gsx.utilities.CommonUtil;

public class SessionCatalog {
	
	public static Properties elementProperties = null;
	public static Properties commonProperties = null;
	private static String actualMsg = null;
	private static String expectedMsg = null;
	private static String status = null;
	public static String selectinterest = null;
	public static List<WebElement> checkboxes = null;
	
	
	static {
		elementProperties = PropertiesFileReader.getInstance().readProperties(
				"element.properties");
		commonProperties = PropertiesFileReader.getInstance().readProperties(
				"common.properties");
	}
	
	public static void validateSessionsPage() throws InterruptedException {
		
		CommonUtil.waitForPageload();
		CommonUtil.explicitlyWait(10);
		//CommonUtil.wait("cisco.gsx.sessioncatalog.button.viewagenda");
		actualMsg = "My Account Profile";
		expectedMsg = CommonUtil.getText(elementProperties
				.getProperty("cisco.gsx.registration.Paymentinfo.text"));
		if (actualMsg.equalsIgnoreCase(expectedMsg)) {
			actualMsg = "User login succeed";
			expectedMsg = "User successfully logged in";
			status = "PASS";
			CommonUtil.logMessage(expectedMsg, actualMsg, status);
		} else {
			System.out.println("not verified");
			actualMsg = "User login failed";
			expectedMsg = "User successfully logged in";
			status = "FAIL";
			CommonUtil.logMessage(expectedMsg, actualMsg, status);
		}
		CommonUtil.waitForPageload();	
	}
	
	public static void clickAgenda() {
		
		//CommonUtil.waitForPageload();
		CommonUtil.explicitlyWait(2);
		//CommonUtil.wait("cisco.gsx.sessioncatalog.button.viewagenda");
		CommonUtil.click(elementProperties.getProperty("cisco.gsx.sessioncatalog.button.viewagenda"));
	}
	public static void switchToNewWindow() {
		  CommonUtil.switchToNewWindow();
		 }
	
	public static void validateSessionHomePage() {
		CommonUtil.explicitlyWait(2);
		CommonUtil.waitForPageload();	
		actualMsg = "Search";
		expectedMsg = CommonUtil.getAttribute(elementProperties.getProperty("cisco.gsx.sessioncatalog.button.search"),"value");
		System.out.println("AR " + actualMsg +" and ER " + expectedMsg);
		if (actualMsg.equalsIgnoreCase(expectedMsg)) {
			System.out.println("Actual and Expected messages are same");
			actualMsg = " Session Home page is displayed ";
			expectedMsg = "Session Home page is displayed";
			status = "PASS";
			CommonUtil.logMessage(expectedMsg, actualMsg, status);
		} else {
			System.out.println("Actual and Expected messages are not same");
			actualMsg = " Session Home page failed";
			expectedMsg = " Session Home page is displayed";
			status = "FAIL";
			CommonUtil.logMessage(expectedMsg, actualMsg, status);
		}
		
		
		CommonUtil.waitForPageload();
	}
	
	public static void selectInterest() throws InterruptedException {
		CommonUtil.explicitlyWait(2);
		CommonUtil.waitForPageload();
		System.out.println(CommonUtil.getAttribute(elementProperties.getProperty("cisco.gsx.sessioncatalog.secondinterestclass"),"class"));
		if(CommonUtil.getAttribute(elementProperties.getProperty("cisco.gsx.sessioncatalog.secondinterestclass"),"class").equalsIgnoreCase("interest interested"))
		{
				System.out.println("class name is verified");
				CommonUtil.click(elementProperties.getProperty("cisco.gsx.sessioncatalog.secondinterest"));
				
				//CommonUtil.waitForPageload();
				//CommonUtil.click(elementProperties.getProperty("cisco.gsx.sessioncatalog.secondinterest"));
				Thread.sleep(6000);
				
				//CommonUtil.waitForPageload();
				actualMsg = "Add to My Interests";
				expectedMsg = CommonUtil.getText(elementProperties
						.getProperty("cisco.gsx.sessioncatalog.secondinterest"));
				System.out.println("AR " + actualMsg +" and ER " + expectedMsg);
				if (actualMsg.equalsIgnoreCase(expectedMsg))
				{
					System.out.println("Actual and Expected messages are same");
					actualMsg = "Added to My Interests";
					expectedMsg = "Added to My Interests";
					status = "PASS";
					CommonUtil.logMessage(expectedMsg, actualMsg, status);
					CommonUtil.click(elementProperties.getProperty("cisco.gsx.sessioncatalog.secondinterest"));
					selectinterest = CommonUtil.getText(elementProperties.getProperty("cisco.gsx.sessioncatalog.catalog.secondsession"));
					System.out.println("Interest"+selectinterest);
					
				} 
				else 
				{
					System.out.println("Actual and Expected messages are not same");
					actualMsg = "Add to My Interests failed";
					expectedMsg = "Added to My Interests";
					status = "FAIL";
					CommonUtil.logMessage(expectedMsg, actualMsg, status);
			    }
		}
		else
		{
			System.out.println("add to my interests clicked");
		  //  CommonUtil.click(elementProperties.getProperty("cisco.gsx.sessioncatalog.secondinterest"));
			actualMsg = "Add to My Interests";
			expectedMsg = CommonUtil.getText(elementProperties
					.getProperty("cisco.gsx.sessioncatalog.secondinterest"));
			System.out.println("AR " + actualMsg +" and ER " + expectedMsg);
			if (actualMsg.equalsIgnoreCase(expectedMsg)) 
			{
				System.out.println("Actual and Expected messages are same");
				actualMsg = "Added to My Interests";
				expectedMsg = "Added to My Interests";
				status = "PASS";
				CommonUtil.logMessage(expectedMsg, actualMsg, status);
				CommonUtil.click(elementProperties.getProperty("cisco.gsx.sessioncatalog.secondinterest"));
				selectinterest = CommonUtil.getText(elementProperties.getProperty("cisco.gsx.sessioncatalog.catalog.secondsession"));
				
			} else 
			{
				System.out.println("Actual and Expected messages are not same");
				actualMsg = "Add to My Interests failed";
				expectedMsg = "Added to My Interests";
				status = "FAIL";
				CommonUtil.logMessage(expectedMsg, actualMsg, status);
				
			}
		}
	}
		
		
		
		
	
	
	public static void clickMyIntrests() {
		CommonUtil.explicitlyWait(2);
		CommonUtil.waitForPageload();
		CommonUtil.click(elementProperties.getProperty("cisco.gsx.sessioncatalog.myinterests"));
	}
	
	public static void validateMyIntrestsHomePage() {
		CommonUtil.explicitlyWait(2);
		CommonUtil.waitForPageload();
		actualMsg = "My Interests";
		expectedMsg = CommonUtil.getText(elementProperties
				.getProperty("cisco.gsx.sessioncatalog.myinterestsheading"));
		System.out.println("AR " + actualMsg +" and ER " + expectedMsg);
		if (actualMsg.equalsIgnoreCase(expectedMsg)) {
			System.out.println("Actual and Expected messages are same");
			actualMsg = "My Interest Home page is displayed";
			expectedMsg = "My Interest Home page is displayed";
			status = "PASS";
			CommonUtil.logMessage(expectedMsg, actualMsg, status);
		} else {
			System.out.println("Actual and Expected messages are not same");
			actualMsg = " My Interest Home page failed";
			expectedMsg = " My Interest Home page is displayed";
			status = "FAIL";
			CommonUtil.logMessage(expectedMsg, actualMsg, status);
		}
		CommonUtil.waitForPageload();
	}
	
	public static void verifySelectedIntrests() {
		CommonUtil.explicitlyWait(2);
		CommonUtil.waitForPageload();	
		List<WebElement> list= CommonUtil.findElements(elementProperties.getProperty("cisco.gsx.sessioncatalog.myintrests.titles"));
		System.out.println("Interest"+selectinterest);

		for(WebElement s:list)
		{
			System.out.println(s.getText()+"****"+selectinterest);
		  if(s.getText().equalsIgnoreCase(selectinterest))
		  { 
			  System.out.println("passed");
		  }
		  
		}
		CommonUtil.click(elementProperties.getProperty("cisco.gsx.sessioncatalog.catalog.SessionCatalog"));
		CommonUtil.waitForPageload();
	}
	
	

	public static void ValidateSessionType()
	{
		CommonUtil.explicitlyWait(2);
		checkboxes = CommonUtil.findElements(elementProperties.getProperty("cisco.gsx.sessioncatalog.Sessiontype.checkboxes"));
		System.out.println("Type"+checkboxes.size());
		CommonUtil.explicitlyWait(1);
		
		for(int i=0;i<checkboxes.size();i++)
		{	
		
		   checkboxes.get(i).getAttribute("id");
		
				if(checkboxes.get(i).getAttribute("id").equalsIgnoreCase("sessionType_1000")) {
					
					CommonUtil.click(elementProperties.getProperty("cisco.gsx.sessioncatalog.Sessiontype.breakoutcheckbox"));
					CommonUtil.explicitlyWait(2);
					//Need to change (Breakout (BR)) text in code
					//SessionCatalog.validateSessionTypes(elementProperties.getProperty("cisco.gsx.sessioncatalog.Sessiontype.Breakname"), "Breakout (BR)" );
					SessionCatalog.validateSessionTypes(elementProperties.getProperty("cisco.gsx.sessioncatalog.Sessiontype.Breakname"), "Breakout Session" );
					CommonUtil.click(elementProperties.getProperty("cisco.gsx.sessioncatalog.Sessiontype.breakoutcheckbox"));
					CommonUtil.explicitlyWait(1);
				} 
				/*else if(checkboxes.get(i).getAttribute("id").equalsIgnoreCase("sessionType_1001")) {
					
					CommonUtil.click(elementProperties.getProperty("cisco.gsx.sessioncatalog.Sessiontype.GeneralSessioncheckbox"));
					CommonUtil.explicitlyWait(1);
					SessionCatalog.validateSessionTypes(elementProperties.getProperty("cisco.gsx.sessioncatalog.Sessiontype.Generalsessionname"), "General Session (GS)");
					CommonUtil.click(elementProperties.getProperty("cisco.gsx.sessioncatalog.Sessiontype.GeneralSessioncheckbox"));
					CommonUtil.explicitlyWait(1);
					
				} else if(checkboxes.get(i).getAttribute("id").equalsIgnoreCase("sessionType_1040")) {
					
					CommonUtil.click(elementProperties.getProperty("cisco.gsx.sessioncatalog.Sessiontype.HubSessioncheckbox"));
					CommonUtil.explicitlyWait(1);
					SessionCatalog.validateSessionTypes(elementProperties.getProperty("cisco.gsx.sessioncatalog.Sessiontype.HubSessionname"), "Hub Session");
					CommonUtil.click(elementProperties.getProperty("cisco.gsx.sessioncatalog.Sessiontype.HubSessioncheckbox"));
					CommonUtil.explicitlyWait(1);
					
					
				} else if(checkboxes.get(i).getAttribute("id").equalsIgnoreCase("sessionType_1020")) {
					
					CommonUtil.click(elementProperties.getProperty("cisco.gsx.sessioncatalog.Sessiontype.Region/Segmentcheckbox"));
					CommonUtil.explicitlyWait(1);
					SessionCatalog.validateSessionTypes(elementProperties.getProperty("cisco.gsx.sessioncatalog.Sessiontype.Regionsegmentname"),"Region/Segment (RS)");
					CommonUtil.click(elementProperties.getProperty("cisco.gsx.sessioncatalog.Sessiontype.Region/Segmentcheckbox"));
					CommonUtil.explicitlyWait(1);
					
				}*/
				else if(checkboxes.get(i).getAttribute("id").equalsIgnoreCase("sessionType_1021"))
				{
					CommonUtil.explicitlyWait(2);
					CommonUtil.click(elementProperties.getProperty("cisco.gsx.sessioncatalog.Sessiontype.SuperSessioncheckbox"));
					CommonUtil.explicitlyWait(4);
					
					//Region/Segment (RS)
					SessionCatalog.validateSessionTypes(elementProperties.getProperty("cisco.gsx.sessioncatalog.Sessiontype.Supersessionname"),"Super Sessions");
					CommonUtil.click(elementProperties.getProperty("cisco.gsx.sessioncatalog.Sessiontype.SuperSessioncheckbox"));
					CommonUtil.explicitlyWait(1);
				}
		}
		CommonUtil.waitForPageload();
	}
	
	
	
	
public static void SessionCatalogTrack() {
	CommonUtil.explicitlyWait(2);
	System.out.println("Track");
	
		
		checkboxes = CommonUtil.findElements(elementProperties.getProperty("cisco.gsx.sessioncatalog.catalog.Trackboxes"));
		System.out.println("Track"+checkboxes.size());
		CommonUtil.explicitlyWait(1);
		
		for(int i=0;i<3;i++)
		{	
			System.out.println(checkboxes.get(i).getAttribute("id"));
			if(checkboxes.get(i).getAttribute("id").equalsIgnoreCase("profileItem_10314_10577")) {
//				
					System.out.println("stageric");
					CommonUtil.click(elementProperties.getProperty("cisco.gsx.sessioncatalog.catalog.Amgotomarket"));
					System.out.println("click is working");
					CommonUtil.waitForPageload();
					CommonUtil.explicitlyWait(3);
					CommonUtil.click(elementProperties.getProperty("cisco.gsx.sessioncatalog.catalog.AMGotomarket.link"));
					CommonUtil.explicitlyWait(1);
					CommonUtil.switchToFrame();
					CommonUtil.isAlertPresent();
					SessionCatalog.validateTrack(elementProperties.getProperty("cisco.gsx.sessioncatalog.catalog.Track.text"), "AM - Go To Market");
					CommonUtil.click(elementProperties.getProperty("cisco.gsx.sessioncatalog.catalog.Amgotomarket"));
					CommonUtil.explicitlyWait(1);
					
				
				
			}else if(checkboxes.get(i).getAttribute("id").equalsIgnoreCase("profileItem_10314_10576")) {
					System.out.println("sucess");
					
					CommonUtil.click(elementProperties.getProperty("cisco.gsx.sessioncatalog.catalog.SalesCultureandTalent"));
					CommonUtil.waitForPageload();
					CommonUtil.explicitlyWait(2);
					CommonUtil.click(elementProperties.getProperty("cisco.gsx.sessioncatalog.catalog.SalesCultureandTalent.link"));
					CommonUtil.explicitlyWait(1);
					CommonUtil.switchToFrame();
					CommonUtil.isAlertPresent();
					SessionCatalog.validateTrack(elementProperties.getProperty("cisco.gsx.sessioncatalog.catalog.Track.text"), "Sales Culture and Talent" );
					CommonUtil.click(elementProperties.getProperty("cisco.gsx.sessioncatalog.catalog.SalesCultureandTalent"));
					CommonUtil.waitForPageload();
					CommonUtil.explicitlyWait(1);
					
					
				} else if(checkboxes.get(i).getAttribute("id").equalsIgnoreCase("profileItem_10314_10541")) {
				
					
					CommonUtil.click(elementProperties.getProperty("cisco.gsx.sessioncatalog.catalog.SETechnicalSolutions"));
					CommonUtil.waitForPageload();
					CommonUtil.explicitlyWait(3);
					CommonUtil.click(elementProperties.getProperty("cisco.gsx.sessioncatalog.catalog.SETechnicalSolutions.link"));
					CommonUtil.explicitlyWait(2);
					CommonUtil.switchToFrame();
					CommonUtil.isAlertPresent();
					SessionCatalog.validateTrack(elementProperties.getProperty("cisco.gsx.sessioncatalog.catalog.Track.text"), "SE - Technical Solutions" );
					CommonUtil.waitForPageload();
					CommonUtil.explicitlyWait(1);
					CommonUtil.click(elementProperties.getProperty("cisco.gsx.sessioncatalog.catalog.SETechnicalSolutions"));
					CommonUtil.explicitlyWait(1);
				}
		
				CommonUtil.waitForPageload();
		}
}



public static void validateSessionTypes(String sessionTypeXpath, String sessionTypeName) {
	
		CommonUtil.explicitlyWait(1);
		List<WebElement> SessionTitles=CommonUtil.findElements(elementProperties.getProperty("cisco.gsx.sessioncatalog.Sessiontype.titles"));
		System.out.println("Session Titles"+SessionTitles.size());
		CommonUtil.explicitlyWait(1);
		List<WebElement> sessionTypeNames=CommonUtil.findElements(sessionTypeXpath);
		actualMsg = Integer.toString(SessionTitles.size());
		expectedMsg = Integer.toString(sessionTypeNames.size());
		System.out.println("actual"+actualMsg+"*****"+expectedMsg);
		
		if (actualMsg.equalsIgnoreCase(expectedMsg)) 
		{
			System.out.println("Actual and Expected messages are same");
			actualMsg = sessionTypeName + " session type is verified successfully ";
			expectedMsg =  sessionTypeName + " session type is verified successfully";
			status = "PASS";
			CommonUtil.logMessage(expectedMsg, actualMsg, status);
		} 
		else 
		{
			System.out.println("Actual and Expected messages are not same");
			actualMsg = sessionTypeName+ " session type verification is failed";
			expectedMsg =  sessionTypeName + " session type is verified successfully";
			status = "FAIL";
			CommonUtil.logMessage(expectedMsg, actualMsg, status);
		}
}

public static void validateTrack(String sessionTypeXpath, String sessionTypeName)
{
		CommonUtil.explicitlyWait(1);
		expectedMsg = sessionTypeName;//AM - Go To Market
		System.out.println("Expected Message : "+expectedMsg);
		
		actualMsg = CommonUtil.getText(sessionTypeXpath);
		
		

		System.out.println("Actual Message : "+actualMsg);
		
		if (actualMsg.equalsIgnoreCase(expectedMsg)) 
		{
			System.out.println("Actual and Expected messages are same");
			actualMsg = sessionTypeName + " Track is successfully verified";
			expectedMsg =  sessionTypeName + " Track is verified successfully";
			status = "PASS";
			CommonUtil.logMessage(expectedMsg, actualMsg, status);
			CommonUtil.switchToDefault();
			//CommonUtil.explicitlyWait(3);
			CommonUtil.ESCAPE();
			//CommonUtil.click(elementProperties.getProperty("cisco.gsx.sessioncatalog.close"));
			CommonUtil.waitForPageload();
			CommonUtil.explicitlyWait(2);

			
		} 
		else 
		{
			System.out.println("Actual and Expected messages are not same");
			actualMsg = sessionTypeName+ " Track verification is failed";
			expectedMsg =  sessionTypeName + " Track is verified successfully";
			status = "FAIL";
			CommonUtil.logMessage(expectedMsg, actualMsg, status);
		}
}
public static void SessionCategory() {
	
	System.out.println("Category");
		
		
		checkboxes = CommonUtil.findElements(elementProperties.getProperty("cisco.gsx.sessioncatalog.Category.checkboxes"));
		System.out.println(checkboxes.size());
		CommonUtil.explicitlyWait(1);
		for(int i=0;i<checkboxes.size();i++)
		{	
			//System.out.println(checkboxes.get(i).getAttribute("id"));
			if(checkboxes.get(i).getAttribute("id").equalsIgnoreCase("profileItem_10312_14334")) {

					System.out.println("Captial");
					CommonUtil.click(elementProperties.getProperty("cisco.gsx.sessioncatalog.catalog.CiscoCaptial"));
					System.out.println("click is working");
					CommonUtil.waitForPageload();
					CommonUtil.explicitlyWait(2);
					CommonUtil.click(elementProperties.getProperty("cisco.gsx.sessioncatalog.catalog.Ciscocapital.link"));
					CommonUtil.explicitlyWait(1);
					CommonUtil.switchToFrame();
					CommonUtil.isAlertPresent();
					SessionCatalog.validateCategory(elementProperties.getProperty("cisco.gsx.sessioncatalog.catalog.Category.text"), "Cisco Capital");
					CommonUtil.click(elementProperties.getProperty("cisco.gsx.sessioncatalog.catalog.CiscoCaptial"));
					CommonUtil.explicitlyWait(1);
					
				
				
			}else if(checkboxes.get(i).getAttribute("id").equalsIgnoreCase("profileItem_10312_10534")) {
					System.out.println("sucess");
					
					CommonUtil.click(elementProperties.getProperty("cisco.gsx.sessioncatalog.catalog.Collaborations"));
					CommonUtil.waitForPageload();
					CommonUtil.explicitlyWait(8);
					CommonUtil.click(elementProperties.getProperty("cisco.gsx.sessioncatalog.catalog.Collaborations.link"));
					CommonUtil.explicitlyWait(1);
					CommonUtil.switchToFrame();
					CommonUtil.isAlertPresent();
					SessionCatalog.validateCategory(elementProperties.getProperty("cisco.gsx.sessioncatalog.catalog.Category.text"), "Collaboration" );
					CommonUtil.click(elementProperties.getProperty("cisco.gsx.sessioncatalog.catalog.Collaborations"));
					CommonUtil.waitForPageload();
					CommonUtil.explicitlyWait(1);
					
					
				}
		
		}
}
public static void validateCategory(String sessionTypeXpath, String sessionTypeName)
{
		CommonUtil.explicitlyWait(1);
		expectedMsg = sessionTypeName;
		System.out.println("Expected Message : "+expectedMsg);
		
		actualMsg = CommonUtil.getText(sessionTypeXpath);			

		System.out.println("Actual Message : "+actualMsg);		
		if (actualMsg.equalsIgnoreCase(expectedMsg)) 
		{
			System.out.println("Actual and Expected messages are same");
			actualMsg = sessionTypeName + " Category is successfully verified";
			expectedMsg =  sessionTypeName + " Category is verified successfully";
			status = "PASS";
			CommonUtil.logMessage(expectedMsg, actualMsg, status);
			CommonUtil.switchToDefault();
			CommonUtil.ESCAPE();
			//CommonUtil.click(elementProperties.getProperty("cisco.gsx.sessioncatalog.close"));
			CommonUtil.waitForPageload();
			CommonUtil.explicitlyWait(2);
			
		} 
		else 
		{
			System.out.println("Actual and Expected messages are not same");
			actualMsg = sessionTypeName+ " Category verification is failed";
			expectedMsg =  sessionTypeName + " Category is verified successfully";
			status = "FAIL";
			CommonUtil.logMessage(expectedMsg, actualMsg, status);
		}
}



}


